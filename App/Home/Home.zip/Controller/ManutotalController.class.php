<?php

/**
 *      稿件统计控制器
 */

namespace Home\Controller;
use Think\Controller;

class ManutotalController extends CommonController{
	
   public function index() {
	   //获取所有用户
	   $this->userlist=M('user')->field('id,username,truename')->select();
	   if(!in_array(session('uid'),C('ADMINISTRATOR'))){
		  $where['uid']=session('uid');
	   }
	   $uname='总计';
	   if($uid=$_REQUEST['juid']){
		   $this->juname=$_REQUEST['juname'];
		   $this->juid=$uid;
		   $where['uid']=array('in',$uid);
		   if(!in_array(session('uid'),C('ADMINISTRATOR'))){
		  $this->uid=$_REQUEST['uid'];
			$uname='';
	   }
	   		
			}
	   if(isset($_REQUEST['time1']) && $_REQUEST['time1'] != ''&&isset($_REQUEST['time2']) && $_REQUEST['time2'] != ''){
		   $where['updtime'] =array(array('egt',I('time1').' 00:00:00'),array('elt',I('time2').' 59:59:59'));
	   }
	   $where['pubid']=array('gt',0);
		$list=M('manuscript')->field("count(1) as sl,pubid,uname")->where($where)->group('pubid')->select();
		
		foreach($list as $k=>&$v){
			$v['pubname']=D('datalist')->getselectname($v['pubid']);
			}
		$this->uname=$uname? $uname:$list[0]['uname'];
		$this->list=$list;
		$this->display();

	}
   
   
}