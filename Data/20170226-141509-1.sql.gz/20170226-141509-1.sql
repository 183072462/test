-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : zhengwu
-- 
-- Part : #1
-- Date : 2017-02-26 14:15:09
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `xy_auth_group`
-- -----------------------------
DROP TABLE IF EXISTS `xy_auth_group`;
;

-- -----------------------------
-- Records of `xy_auth_group`
-- -----------------------------
INSERT INTO `xy_auth_group` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `xy_auth_group` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `xy_auth_group` VALUES ('', '', '', '', '', '', '', '');
